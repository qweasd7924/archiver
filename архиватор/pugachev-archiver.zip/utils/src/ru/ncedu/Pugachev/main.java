package ru.ncedu.Pugachev;

import java.io.*;
import java.util.zip.*;

public class main{
    public static void main(String[] args) throws IOException {

        ArchiverImpl a = new ArchiverImpl();
        a.manipulInputString();

//        input stream
//        D:\\ZipFileInput.zip   D:\\aaa.txt   D:\\pict.jpg  D:\\music.mp3
//        unpack
//        D:\\ZipFileInput.zip unpack_to E:\\aaa\\bbb\\
//        add
//        D:\\ToCopy.zip  add  D:\\ccc.txt

    }
}
